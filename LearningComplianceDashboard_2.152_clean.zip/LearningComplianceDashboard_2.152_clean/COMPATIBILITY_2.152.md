# Power BI Desktop 2.152 clean compatibility package

This folder is a clean PBIP source package intended for **Power BI Desktop 2.152.882.0 (64-bit)**.

## How to send/open it

1. Zip this entire folder, not just the `.pbip` file.
2. On the target machine, unzip the folder.
3. Open `LearningComplianceDashboard.pbip` in Power BI Desktop 2.152.882.0.
4. Ensure the PBIR preview feature is enabled if Desktop asks for it.
5. Let Power BI Desktop 2.152 rebuild/load the sample model data.
6. Save as PBIX from Power BI Desktop 2.152.

## What this package intentionally excludes

- No `.pbix` file is included.
- No `.pbi/cache.abf` semantic-model cache is included.
- No local `.pbi` settings are included.

Those files can carry metadata from a newer Desktop build. If a PBIX or cache is created by Desktop 2.155, Desktop 2.152 can warn that the queries/model were built with a newer version.

## Compatibility targets

- Report schema: 3.2.0
- Visual container schema: 2.7.0
- Page schema: 2.1.0
- Pages metadata schema: 1.0.0
- Enhanced PBIR is still required.
