# LearningComplianceDashboard PBIP

This project recreates the revised two-page dashboard—**Executive Overview** and **Training Gaps & Priority Cohorts**—using enhanced PBIR.

The report uses Verdana throughout and maps both revised source images onto the requested 1600 x 900 canvas.

## Prerequisites

- A recent version of Microsoft Power BI Desktop that supports Power BI Desktop projects (PBIP) and TMDL semantic models.
- The PBIP, report, and semantic-model folders must remain together with their current relative names.

## Open the project

1. Close any older copy of the project in Power BI Desktop.
2. In File Explorer, open `LearningComplianceDashboard.pbip`.
3. Alternatively, start Power BI Desktop, select **File > Open**, and choose `LearningComplianceDashboard.pbip`.
4. Allow Power BI Desktop to load the local semantic model.
5. If Desktop prompts to apply or refresh changes, choose **Apply changes** or **Refresh**. All placeholder data is embedded in Power Query M expressions, so no external credentials are required.
6. Save the project after Power BI Desktop has upgraded any local metadata required by the installed Desktop version.

## Included

- Two report pages: **Executive Overview** and **Training Gaps & Priority Cohorts**
- Five native KPI cards
- Native stacked bar chart for band compliance
- Native Matrix visual for the Band × Sector compliance heatmap
- Native doughnut chart for the mandatory/optional split
- A native employee risk/detail table on Page 2
- Page 2 defaulter, behind-schedule, low-hours, criteria, and filter panels
- Power BI text boxes and styled containers for the header, navigation, target strip, filters, and KPI annotations
- Workbook-aligned input tables matching `Input File Structure.xlsx`
- Embedded representative rows for previewing the report without an external data connection
- Enhanced PBIR page and visual definitions under `LearningComplianceDashboard.Report/definition/pages`

The former third page has been removed. Both remaining pages use a 1600 x 900 canvas and Verdana.

## Input structure and refresh behavior

The semantic model includes tables matching all six workbook sheets: `Emp Info`, `General Trainings`, `Mandatory Trainings`, `Special Training-1`, `Special Training-2`, and `Special Training-3`.

The source is expected to contain cumulative calendar-year data through the latest completed month. For example, a 1 July refresh contains 1 January-30 June data; a 1 September refresh contains 1 January-31 August data. The dashboard header is stamped with the current project-generation timestamp.

June is explicitly highlighted as the active 50% Monthly Target Pct state on both pages.

## Project structure

- `LearningComplianceDashboard.pbip` - project entry point
- `LearningComplianceDashboard.Report` - enhanced PBIR report, page, and visual definitions
- `LearningComplianceDashboard.SemanticModel` - TMDL model and embedded sample data

## Validation note

The project files are generated as text and checked for valid enhanced PBIR JSON, relative-path consistency, and report-to-model field references. Final rendering must be confirmed by opening the PBIP in the target Power BI Desktop build, because Desktop is not installed in this workspace environment.
